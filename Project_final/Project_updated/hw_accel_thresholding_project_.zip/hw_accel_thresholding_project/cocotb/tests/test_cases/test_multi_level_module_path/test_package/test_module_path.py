# Copyright cocotb contributors
# Licensed under the Revised BSD License, see LICENSE for details.
# SPDX-License-Identifier: BSD-3-Clause

"""Test for multi-level module path in MODULE"""

import cocotb


@cocotb.test()
async def test_pass(_):
    pass
