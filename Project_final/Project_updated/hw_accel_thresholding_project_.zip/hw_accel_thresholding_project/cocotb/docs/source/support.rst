************
Getting Help
************

Getting in Contact with a Maintainer
====================================

All of the :ref:`maintainers <maintainers>` are active on the `Gitter channel <https://gitter.im/cocotb/Lobby>`__.
They prefer inquiries go through direct messages on Gitter,
or by mentioning them in the main `cocotb Gitter channel <https://gitter.im/cocotb/Lobby>`__ using ``@{maintainer name}``.
Maintainers are unpaid volunteers, so it might take a while for a maintainer to get back to you.


Code of Conduct
===============

The cocotb development community aims to be welcoming to everyone.
The `FOSSi Foundation Code of Conduct <https://www.fossi-foundation.org/code-of-conduct>`__ applies.
Please contact any of the maintainers if you feel uncomfortable in the cocotb development community.
