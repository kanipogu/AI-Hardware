..
   This file is a placeholder and will be replaced by Sphinx
   This is a hack to put the module index in the toctree
   See https://stackoverflow.com/a/42310803

*****
Index
*****
