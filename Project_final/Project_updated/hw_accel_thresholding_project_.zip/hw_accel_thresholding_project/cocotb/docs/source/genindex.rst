..
   This file is a placeholder and will be replaced by Sphinx
   See https://stackoverflow.com/a/42310803

*****
Index
*****
