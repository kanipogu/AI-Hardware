# Cocotb Contribution Guidelines

cocotb welcomes contributions from anyone!
Please have a look at the [Development & Community](https://docs.cocotb.org/en/development/contributing.html) section of the cocotb documentation for an in-depth contribution guide.
