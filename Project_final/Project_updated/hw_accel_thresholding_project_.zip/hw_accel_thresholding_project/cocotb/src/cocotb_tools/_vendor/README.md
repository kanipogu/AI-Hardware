# Vendored libraries to support cocotb_tools

### distutils_version.py

Originally from distutils.py from CPython, vendored in on 2021-09-23.
Needed to support `cocotb_tools.sim_versions`.
Upstream CPython removed `distutils.py`.
